export interface ServiceIconProps {
    className?: string;
}
